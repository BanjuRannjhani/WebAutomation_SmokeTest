import Page from './basic-page-model';

fixture `My first fixture`
    .page `https://www.phptravels.net/`;

const page = new Page();

test('My first Page' ,async t => {
	await t
	.click(page.logindropdown)
	.click(page.login)
	 .typeText(page.nameInput, 'user@phptravels.com')
	 .typeText(page.passwor, 'demouser')
        .click(page.submitbutton)
		.expect(page.nameInput.value).contains('Demo User');
        .click(page.featureList[0].checkbox)
        .click(page.mainpage)
        .click(page.interfaceSelectOption.withText('Both'))
        .expect(page.nameInput.value).contains('Peter');